//
//  ViewController.m
//  TLJSOCCordova
//
//  Created by lichuanjun on 2018/3/28.
//  Copyright © 2018年 lichuanjun. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
//    self.startPage = @"http://m.baidu.com";
    
    [super viewDidLoad];
    
    // 这里空出的20，是为了不显示使用导航控制器时，控制背景色来改变状态栏背景色
    self.webView.frame = CGRectMake(0, 20, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) - 20);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES];
}

@end
