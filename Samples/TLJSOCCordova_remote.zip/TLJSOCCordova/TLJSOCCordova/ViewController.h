//
//  ViewController.h
//  TLJSOCCordova
//
//  Created by lichuanjun on 2018/3/28.
//  Copyright © 2018年 lichuanjun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDVViewController.h"

@interface ViewController : CDVViewController


@end

